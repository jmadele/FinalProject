package com.example.minjia.finalproject;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class FoodNutrition extends Activity {

    private static final String ACTIVITY_NAME = "Food Nutrition Activity";
    private ProgressBar FoodNutritionProgressBar;
    private ImageView FoodNutritionImage;
    private TextView FoodNutritionView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_nutrition);

        FoodNutritionProgressBar = findViewById(R.id.progressBar);
        FoodNutritionImage=findViewById(R.id.foodNutritionImage);
        FoodNutritionView=findViewById(R.id.foodNutritionView);

    }
}
